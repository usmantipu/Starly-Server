import { Request, Response } from 'express'
import { messaging } from 'firebase-admin'
import { firebaseAdmin } from '../config/firebase.js'
import FirebaseAdminUtils from '../utils/adminUtils.js'

const FirebaseController = {
	sendPushNotificationOnNewUser: async (req: Request, res: Response) => {
		try {
			const { userName, imageUrl, liveId, isHost, userId } = req.body
			const allUserTokens: string[] = await FirebaseAdminUtils.getAllUserTokens(
				userId
			)
			const tokens = allUserTokens.filter((t) => t && t !== '')
			if (tokens.length > 0) {
				const CHUNK_SIZE = 500
				const tokenChunks = FirebaseAdminUtils.chunkArray(tokens, CHUNK_SIZE)
				for (const tokenChunk of tokenChunks) {
					const messages: messaging.Message[] = tokenChunk.map((token) => ({
						data: {
							liveId: liveId.toString(),
							isHost: isHost.toString(),
							userId: userId.toString(),
							userName: userName.toString(),
						},
						notification: {
							title: 'New Live Stream!',
							body: `${userName} has created a new live stream`,
							imageUrl: imageUrl,
						},
						token: token,
					}))
					const response = await firebaseAdmin.messaging().sendEach(messages)

					console.log(
						`${response.successCount} messages were sent successfully`
					)
					response.responses.forEach((resp, idx) => {
						if (
							resp.error &&
							resp.error.code === 'messaging/registration-token-not-registered'
						) {
							const invalidToken = tokenChunk[idx]
							console.error('Token not registered:', invalidToken, resp.error)
						}
					})
				}

				res.json({ success: true })
			} else {
				console.warn('No valid tokens available')
				res.json({
					success: false,
					message: 'No valid tokens available.',
				})
			}
		} catch (error) {
			console.error('Error sending push notification:', error)
			res.json({ success: false })
		}
	},
	sendPushNotificationOnNewPost: async (req: Request, res: Response) => {
		try {
			const { userName, imageUrl, userId } = req.body
			const allUserTokens: string[] =
				await FirebaseAdminUtils.getAllFollowersToken(userId)

			if (allUserTokens && allUserTokens.length > 0) {
				const CHUNK_SIZE = 500
				const tokenChunks = FirebaseAdminUtils.chunkArray(
					allUserTokens,
					CHUNK_SIZE
				)
				for (const tokenChunk of tokenChunks) {
					const messages: messaging.Message[] = tokenChunk.map((token) => ({
						notification: {
							title: 'New Post',
							body: `${userName} has added a new Post`,
							imageUrl: imageUrl,
						},
						token: token,
					}))
					const response = await firebaseAdmin.messaging().sendEach(messages)

					console.log(
						`${response.successCount} messages were sent successfully`
					)
					response.responses.forEach((resp, idx) => {
						if (
							resp.error &&
							resp.error.code === 'messaging/registration-token-not-registered'
						) {
							const invalidToken = tokenChunk[idx]
							console.error('Token not registered:', invalidToken, resp.error)
						}
					})
				}

				res.json({ success: true })
			} else {
				console.warn('No valid tokens found for user:', userId)
				res.json({
					success: false,
					message: 'No valid tokens available.',
				})
			}
		} catch (error) {
			console.error('Error sending push notification:', error)
			res.json({ success: false })
		}
	},

	sendNotificationToUser: async (req: Request, res: Response) => {
		try {
			const { imageUrl, title, body, userId } = req.body
			const userCol = await firebaseAdmin
				.firestore()
				.collection('Users')
				.where('uid', '==', userId)
				.get()
			const userDoc = userCol.docs[0].data()
			let token = userDoc.fcm
			if (token && token !== '') {
				const messages = {
					notification: {
						title,
						body,
						imageUrl: imageUrl,
					},
					token: token,
				}
				await firebaseAdmin.messaging().send(messages)
			}
			res.json({ success: true })
		} catch (error) {
			console.error('Error sending push notification:', error)
			res.json({ success: false })
		}
	},
}

export default FirebaseController
